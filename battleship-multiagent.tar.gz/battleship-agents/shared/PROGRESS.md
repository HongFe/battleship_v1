# PROGRESS.md — 전체 진행 상황
Last updated: [날짜]

## Planning Agent
- [ ] docs/GDD.md 초안
- [ ] docs/balance.json v0.1
- [ ] docs/item-spec.md
- [ ] docs/ux-flow.md
- [ ] docs/map-spec.md

## Dev Agent
- [ ] 프로젝트 세팅 (Phaser3+TS+Vite)
- [ ] src/config/types.ts
- [ ] Ship 기본 이동
- [ ] AutoAttackSystem
- [ ] ItemSystem
- [ ] EconomySystem + ShopOverlay
- [ ] SafeZoneSystem
- [ ] 모바일 터치 최적화

## Design Agent
- [ ] design-tokens.json
- [ ] ship_destroyer.png (256x64, 4fr)
- [ ] ship_cruiser.png
- [ ] ship_battleship.png
- [ ] 아이템 아이콘 6종
- [ ] ItemSlot.ts
- [ ] ShopOverlay.ts
- [ ] HUD.ts

## 현재 블로커
없음

## 다음 우선순위
1. Planning: balance.json 완성
2. Design: ship_destroyer.png 납품
3. Dev: types.ts 작성 후 Ship 이동 구현
